##문제 1.1
value = 0
for i in range(0,6) :
     value += 3
     print(value)
   
## 문제 1.2

hap = 0
i = 0

while True :
    i += 1
    if i > 100 :
        break
    elif i%2 == 1 :
        hap += i
            
       
print(hap)
    
