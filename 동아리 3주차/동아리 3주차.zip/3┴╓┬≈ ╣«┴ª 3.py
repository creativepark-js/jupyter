## 문제 3.1

a = [i for i in range(10)]
print(a)



## 문제 3.2

b = [i for i in range(10)]

b.insert(1,201743198)
print(b)

## 문제 3.3


c = [i for i in range(10)]
c.reverse()
c.insert(1,"경영학과")
print(c)


## 문제 3.4
d = [i for i in range(10)]
d.insert(len(d)//2, "박재성")
print(d)
