##3번문제
hour = 8720 # 최저시급 8720
day = 4*hour+2*1.5*hour
weekly = 5*day
salary = 4*weekly
print("A학생의 월급은 ",int(salary),"원입니다",sep='')
