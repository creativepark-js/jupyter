##2번문제
korean , math , english = map(int,input().split('/'))
print("국어,수학,영어의 평균 점수는 " ,int(((korean+math+english)/3)), "점입니다",sep='')



